
/**
 * @brief Main routine for updaiting the OLED screen
 * 
 * @param arg handle to the ssd1306
 */
void ssd1306_main(void* arg);